
package bet18023;

public class Demo {

   
    public static void main(String[] args) {
        // TODO code application logic here
        
        Human human1=new Human();
        Student student1=new Student();
        human1.introduce("person","female");
        student1.introduce("001","abc","male");
    }
    
    
}
