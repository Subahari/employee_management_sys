/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bet18023;

/**
 *
 * @author HP
 */
public class Student {
    String index,name,gender;
    
    void introduce(String index,String name, String gender){
       this.index=index;
        this.name=name;
       this.gender=gender;
       System.out.println(name+" is a "+gender+" student.");
    }
}
